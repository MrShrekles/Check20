const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

// ── CONFIG ──────────────────────────────────────────────────────────────────
// Path to your JSON data folder. Edit this if you move things around.
const DATA_FOLDER = process.env.DATA_FOLDER || 
  'C:\\Users\\Shrek\\Dropbox\\TTRPG\\CODEMONKEY\\Rulebook Project';

// ── MIDDLEWARE ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── HELPERS ──────────────────────────────────────────────────────────────────
function resolveDataPath(...parts) {
  return path.join(DATA_FOLDER, ...parts);
}

function isJsonFile(filename) {
  return filename.endsWith('.json') && !filename.startsWith('.');
}

// Figures out the structure of a JSON file and returns normalized info:
// { type: 'array', data: [...] }
// { type: 'wrapped', key: 'species', data: [...] }
// { type: 'nested', groups: { tank: [...], rogue: [...] } }
function analyzeStructure(parsed) {
  // Plain array: [ {...}, {...} ]
  if (Array.isArray(parsed)) {
    return { type: 'array', data: parsed };
  }

  if (typeof parsed === 'object' && parsed !== null) {
    const keys = Object.keys(parsed);

    // Single-key wrapper with array value: { "species": [...] }
    if (keys.length === 1 && Array.isArray(parsed[keys[0]])) {
      return { type: 'wrapped', key: keys[0], data: parsed[keys[0]] };
    }

    // Single-key wrapper with object of arrays: { "classes": { "tank": [...], "rogue": [...] } }
    if (keys.length === 1 && typeof parsed[keys[0]] === 'object' && !Array.isArray(parsed[keys[0]])) {
      const inner = parsed[keys[0]];
      const innerKeys = Object.keys(inner);
      if (innerKeys.every(k => Array.isArray(inner[k]))) {
        // Flatten all groups into one array, tagging each entry with its group
        const allEntries = [];
        for (const group of innerKeys) {
          for (const entry of inner[group]) {
            allEntries.push({ _group: group, ...entry });
          }
        }
        return { type: 'nested', outerKey: keys[0], groups: inner, data: allEntries };
      }
    }

    // Multi-key object where all values are arrays: { "tank": [...], "rogue": [...] }
    if (keys.every(k => Array.isArray(parsed[k]))) {
      const allEntries = [];
      for (const group of keys) {
        for (const entry of parsed[group]) {
          allEntries.push({ _group: group, ...entry });
        }
      }
      return { type: 'grouped', groups: parsed, data: allEntries };
    }
  }

  // Fallback: treat as single entry wrapped in array
  return { type: 'array', data: [parsed] };
}

// Reconstruct original file structure from flat edited array
function reconstructStructure(structure, editedData) {
  if (structure.type === 'array') {
    return editedData;
  }

  if (structure.type === 'wrapped') {
    return { [structure.key]: editedData };
  }

  if (structure.type === 'nested') {
    // Re-group by _group field
    const groups = {};
    for (const entry of editedData) {
      const { _group, ...rest } = entry;
      const g = _group || Object.keys(structure.groups)[0];
      if (!groups[g]) groups[g] = [];
      groups[g].push(rest);
    }
    return { [structure.outerKey]: groups };
  }

  if (structure.type === 'grouped') {
    const groups = {};
    for (const entry of editedData) {
      const { _group, ...rest } = entry;
      const g = _group || Object.keys(structure.groups)[0];
      if (!groups[g]) groups[g] = [];
      groups[g].push(rest);
    }
    return groups;
  }

  return editedData;
}

// ── ROUTES ───────────────────────────────────────────────────────────────────

// GET /api/files — list all JSON files in the data folder
app.get('/api/files', (req, res) => {
  try {
    if (!fs.existsSync(DATA_FOLDER)) {
      return res.status(404).json({ error: `Data folder not found: ${DATA_FOLDER}` });
    }
    const files = fs.readdirSync(DATA_FOLDER)
      .filter(isJsonFile)
      .map(filename => {
        const filePath = resolveDataPath(filename);
        const stat = fs.statSync(filePath);
        let entryCount = 0;
        try {
          const raw = fs.readFileSync(filePath, 'utf8');
          const parsed = JSON.parse(raw);
          const structure = analyzeStructure(parsed);
          entryCount = structure.data ? structure.data.length : 0;
        } catch (e) { /* bad json, count stays 0 */ }
        return {
          name: filename,
          size: stat.size,
          modified: stat.mtime,
          entryCount
        };
      })
      .sort((a, b) => a.name.localeCompare(b.name));
    res.json({ folder: DATA_FOLDER, files });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/file/:filename — load a specific JSON file
app.get('/api/file/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    if (!isJsonFile(filename)) return res.status(400).json({ error: 'Not a JSON file' });
    const filePath = resolveDataPath(filename);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found' });
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    const structure = analyzeStructure(parsed);
    res.json({ filename, data: structure.data, structure: structure.type, groups: structure.groups || null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/file/:filename — save a JSON file
app.post('/api/file/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    if (!isJsonFile(filename)) return res.status(400).json({ error: 'Not a JSON file' });
    const filePath = resolveDataPath(filename);
    const { data, structure } = req.body;
    if (data === undefined) return res.status(400).json({ error: 'No data provided' });

    // Re-read original to get structure info for reconstruction
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    const originalStructure = analyzeStructure(parsed);
    const reconstructed = reconstructStructure(originalStructure, data);

    fs.writeFileSync(filePath, JSON.stringify(reconstructed, null, 2), 'utf8');
    res.json({ success: true, filename, saved: new Date() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/export/:filename — download a JSON file
app.get('/api/export/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    if (!isJsonFile(filename)) return res.status(400).json({ error: 'Not a JSON file' });
    const filePath = resolveDataPath(filename);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found' });
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/json');
    res.sendFile(filePath);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/folder — change the data folder path at runtime
app.post('/api/folder', (req, res) => {
  const { folder } = req.body;
  if (!folder) return res.status(400).json({ error: 'No folder provided' });
  if (!fs.existsSync(folder)) return res.status(404).json({ error: 'Folder not found' });
  // Dynamically update the path
  process.env.DATA_FOLDER = folder;
  // Reload module's DATA_FOLDER equivalent
  res.json({ success: true, folder });
});

// ── START ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║         SHEK FORGE  v0.1             ║`);
  console.log(`╚══════════════════════════════════════╝`);
  console.log(`  Server running at http://localhost:${PORT}`);
  console.log(`  Data folder: ${DATA_FOLDER}`);
  console.log(`  Open your browser to get started.\n`);
});
